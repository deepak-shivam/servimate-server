module.exports = {
    secretKey : "itsTooSecretMan"
}